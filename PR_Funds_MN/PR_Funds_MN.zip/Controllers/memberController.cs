﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace PR_Funds_MN.Controllers
{
    public class memberController : Controller
    {
        //
        // GET: /member/
        FundEntities db = new FundEntities();

        public ActionResult mem_mainpage()
        {
            if (Session["username"] != null && Session["userroleid"].ToString() != "1")
            {
                ViewBag.message = "Welcome '" + Session["Name"] + "'";
                return View();
            }
            else
            {
                return RedirectToAction("login", "login");
            }

        }


        public ActionResult mem_fundlist()
        {
            if (Session["username"] != null && Session["userroleid"].ToString() != "1")
            {
                
                List<sp_view_fund_collection_new_Result> list = new List<sp_view_fund_collection_new_Result>();
                list = db.sp_view_fund_collection_new().ToList();
                return View(list);
            }
            else
            {
                return RedirectToAction("login", "login");
            }
        }


    }
}